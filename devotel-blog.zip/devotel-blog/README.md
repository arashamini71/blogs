# NestJS Firebase Role Based Auth Blogs

## Features

- Role based authentication with firebase 🔐
- PostgreSQL with TypeORM 💾
- Swagger 📚

### Route access control

Use the following decorators on your controller class :

```ts
@Auth(RoleEnum.ADMIN)
```

This will enable access control for all the routes within this controller and allow the `ADMIN` users to access all routes by default.

If you want for example to additionally allow `USER` users to access a specific route only you can use the same decorator on the route :

````ts
@Auth(RoleEnum.USER)
```

Please see `src/users/users.contoller.ts` as an example.

## Installation

1. Install dependencies

```bash
$ npm install
````

2. Add the `service-account-admin.json` (for firebase authentication)
3. Add the `service-account.json` (for firebase authentication)
4. Create the `.env` file from `.env.example` and replace values.
5. use these account for testing email: admin@admin.com , pass: password
6. import postman from 'Postman-Api/Blogs.postman_collection.json'
7. use this 'http://localhost:3000/blogs' for swagger
8. Setup database

```bash
$ docker-compose up -d

```

## Running

```bash
# development
$ npm run start

# watch mode
$ npm run start:dev

# production mode
$ npm run start:prod
```

## Test

```bash
# unit tests
$ npm run test

# e2e tests
$ npm run test:e2e

# test coverage
$ npm run test:cov
```
