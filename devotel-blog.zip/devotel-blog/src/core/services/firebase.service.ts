import { Injectable } from '@nestjs/common';
import { readFile } from 'fs/promises';
import { RoleEnum } from '../enums/role.enum';
import * as admin from 'firebase-admin';
import { FirebaseApp, initializeApp } from 'firebase/app';
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  getAuth,
  UserCredential,
} from 'firebase/auth';
import { DecodedIdToken } from 'firebase-admin/lib/auth/token-verifier';

let app: admin.app.App;
let firebaseApp: FirebaseApp;

@Injectable()
export class FirebaseService {
  async appInstance() {
    if (app) {
      return app;
    } else {
      app = admin.initializeApp({
        credential: admin.credential.cert('service-account-admin.json'),
      });
      return app;
    }
  }

  async firebaseAppInstance() {
    if (firebaseApp) {
      return firebaseApp;
    } else {
      const firebaseServiceAccountFile = await readFile(
        'service-account.json',
        'utf8',
      );
      const serviceAccount = await JSON.parse(firebaseServiceAccountFile);
      firebaseApp = initializeApp(serviceAccount);
      return firebaseApp;
    }
  }

  async auth() {
    const instance = await this.appInstance();
    return instance.auth();
  }

  async verifyIdToken(idToken: string): Promise<DecodedIdToken> {
    const auth = await this.auth();
    return await auth.verifyIdToken(idToken);
  }

  async setCustomUserClaims(uid: string, role: RoleEnum): Promise<void> {
    const auth = await this.auth();
    await auth.setCustomUserClaims(uid, { role });
  }

  async createUser(email: string, password: string): Promise<UserCredential> {
    const instance = await this.firebaseAppInstance();
    const auth = getAuth(instance);
    return await createUserWithEmailAndPassword(auth, email, password);
  }

  async signInUser(email: string, password: string): Promise<UserCredential> {
    const instance = await this.firebaseAppInstance();
    const auth = getAuth(instance);
    return await signInWithEmailAndPassword(auth, email, password);
  }

  async deleteUser(uid: string): Promise<void> {
    const instance = await this.appInstance();
    await instance.auth().deleteUser(uid);
  }
}
