import { Expose } from 'class-transformer';

export class IBase {
  @Expose()
  id: string;

  @Expose()
  version: number;

  @Expose()
  updatedAt: Date;

  @Expose()
  createdAt: Date;
}

export default IBase;
