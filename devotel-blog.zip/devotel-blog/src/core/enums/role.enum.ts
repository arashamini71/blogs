export enum RoleEnum {
  ADMIN = 'ADMIN',
  USER = 'USER',
}
