import {
  BadRequestException,
  ConflictException,
  Injectable,
} from '@nestjs/common';
import { UserRepository } from '../repositories/user.repository';
import { CreateUserDto } from '../dto/create-user.dto';
import { LoginUserDto } from '../dto/login-user.dto';
import { FirebaseService } from 'src/core/services/firebase.service';
import { UserEntity } from '../models/user.entity';
import { UserCredential } from '@firebase/auth';
import { RoleEnum } from 'src/core/enums/role.enum';

@Injectable()
export class UsersService {
  constructor(
    private readonly usersRepository: UserRepository,
    private readonly firebaseService: FirebaseService,
  ) {}

  async createDefaultAdminUser() {
    try {
      const defaultAdminEmail = 'admin@admin.com';
      const userData = await this.usersRepository.findOne({
        where: { email: defaultAdminEmail },
      });
      if (!userData) {
        const userCredential = await this.firebaseService.createUser(
          defaultAdminEmail,
          'password',
        );

        await this.firebaseService.setCustomUserClaims(
          userCredential.user.uid,
          RoleEnum.ADMIN,
        );

        await this.usersRepository.save({
          email: defaultAdminEmail,
          firstName: 'admin',
          lastName: 'admin',
          firebaseUid: userCredential.user.uid,
          role: RoleEnum.ADMIN,
        });
      }
    } catch (error) {}
  }

  async createUser(createUserDto: CreateUserDto): Promise<UserEntity> {
    let createdUser: UserEntity;
    let userCredential: UserCredential;
    try {
      const userData = await this.usersRepository.findOne({
        where: { email: createUserDto.email },
      });
      if (userData) {
        throw new ConflictException('There is another user with same email');
      }

      userCredential = await this.firebaseService.createUser(
        createUserDto.email,
        createUserDto.password,
      );

      await this.firebaseService.setCustomUserClaims(
        userCredential.user.uid,
        createUserDto.role,
      );

      createdUser = await this.usersRepository.save({
        ...createUserDto,
        firebaseUid: userCredential.user.uid,
      });

      return createdUser;
    } catch (error) {
      if (userCredential) {
        await this.firebaseService.deleteUser(createdUser.id);
      }
      if (createdUser) {
        await this.usersRepository.delete(createdUser.id);
      }
      throw new BadRequestException(error.message);
    }
  }

  async loginUser(loginUserDto: LoginUserDto): Promise<any> {
    try {
      const userData: any = await this.usersRepository.findOne({
        where: { email: loginUserDto.email },
      });
      const userCredential = await this.firebaseService.signInUser(
        loginUserDto.email,
        loginUserDto.password,
      );

      userData.userCredential = userCredential;
      return userData;
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }
}
