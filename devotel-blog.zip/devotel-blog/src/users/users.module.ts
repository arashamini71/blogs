import { Module, OnApplicationBootstrap } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UsersService } from './services/users.service';
import { UsersController } from './controllers/users.controller';
import { UserRepository } from './repositories/user.repository';
import { HttpModule } from '@nestjs/axios';
import { FirebaseService } from 'src/core/services/firebase.service';
import { UserEntity } from './models/user.entity';

@Module({
  imports: [TypeOrmModule.forFeature([UserEntity]), HttpModule],
  providers: [UsersService, FirebaseService, UserRepository],
  exports: [UsersService],
  controllers: [UsersController],
})
export class UsersModule implements OnApplicationBootstrap {
  constructor(private usersService: UsersService) {}
  async onApplicationBootstrap() {
    await this.usersService.createDefaultAdminUser();
  }
}
