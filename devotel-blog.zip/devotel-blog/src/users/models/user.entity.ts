import { Column, Entity, OneToMany } from 'typeorm';
import { BaseEntity } from '../../core/models/base.entity';
import { RoleEnum } from 'src/core/enums/role.enum';
import { PostEntity } from 'src/posts/models/post.entity';

@Entity({ name: 'users' })
export class UserEntity extends BaseEntity {
  @Column({ unique: true, nullable: true })
  firebaseUid: string;

  @Column()
  lastName: string;

  @Column()
  firstName: string;

  @Column({ unique: true })
  email: string;

  @Column({ default: RoleEnum.USER })
  role: RoleEnum;
}
