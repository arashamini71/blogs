import { Column, Entity, JoinColumn, OneToOne } from 'typeorm';
import { BaseEntity } from '../../core/models/base.entity';
import { UserEntity } from 'src/users/models/user.entity';

@Entity({ name: 'posts' })
export class PostEntity extends BaseEntity {
  @OneToOne(() => UserEntity)
  @JoinColumn()
  user: UserEntity;

  @Column()
  title: string;

  @Column()
  content: string;

  @Column({ nullable: true })
  image: string;
}
