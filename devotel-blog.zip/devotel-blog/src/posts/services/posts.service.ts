import {
  BadRequestException,
  ConflictException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { CreatePostDto } from '../dto/create-post.dto';
import { FirebaseService } from 'src/core/services/firebase.service';

import { RoleEnum } from 'src/core/enums/role.enum';
import { PostRepository } from '../repositories/post.repository';
import { PostEntity } from '../models/post.entity';
import { UpdatePostDto } from '../dto/update-post.dto';
import { GetPostDto } from '../dto/get-post.dto';

@Injectable()
export class PostsService {
  constructor(private readonly postsRepository: PostRepository) {}

  async list(getPostDto: GetPostDto): Promise<PostEntity[]> {
    const response = await this.postsRepository.find({
      where: {},
      skip: getPostDto.skip,
      take: getPostDto.take,
    });
    if (!response) {
      throw new NotFoundException('There is no post with the given id');
    }
    return response;
  }

  async getById(id: string): Promise<PostEntity> {
    const response = await this.postsRepository.findOne({
      where: { id: id },
      relations: { user: true },
    });
    if (!response) {
      throw new NotFoundException('There is no post with the given id');
    }
    return response;
  }

  async createPost(createPostDto: CreatePostDto): Promise<PostEntity> {
    const body: any = createPostDto;
    return await this.postsRepository.save(body);
  }

  async updatePostById(
    id: string,
    updatePostDto: UpdatePostDto,
  ): Promise<PostEntity> {
    const currentPost = await this.getById(id);
    await this.postsRepository.update(id, updatePostDto);
    const updatedPost = await this.getById(id);
    return updatedPost;
  }

  async deletePostById(id: string): Promise<void> {
    await this.postsRepository.delete(id);
  }
}
