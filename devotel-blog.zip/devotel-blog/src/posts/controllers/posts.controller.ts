import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { PostsService } from '../services/posts.service';
import { Auth } from 'src/auth/decorators/auth.decorator';
import { RoleEnum } from 'src/core/enums/role.enum';
import { CreatePostDto } from '../dto/create-post.dto';
import { GetPostDto } from '../dto/get-post.dto';
import { UpdatePostDto } from '../dto/update-post.dto';

@ApiTags('Posts')
@Controller('/posts')
export class PostsController {
  constructor(private readonly postsService: PostsService) {}

  @Post()
  @Auth(RoleEnum.USER, RoleEnum.ADMIN)
  createPost(@Body() createPostDto: CreatePostDto) {
    return this.postsService.createPost(createPostDto);
  }

  @Get()
  @Auth(RoleEnum.USER, RoleEnum.ADMIN)
  getList(@Query() getPostDto: GetPostDto) {
    return this.postsService.list(getPostDto);
  }

  @Get('/one/:id')
  @Auth(RoleEnum.USER, RoleEnum.ADMIN)
  getById(@Param('id') id: string) {
    return this.postsService.getById(id);
  }

  @Put('/:id')
  @Auth(RoleEnum.USER, RoleEnum.ADMIN)
  updateById(@Param('id') id: string, @Body() updatePostDto: UpdatePostDto) {
    return this.postsService.updatePostById(id, updatePostDto);
  }

  @Delete('/:id')
  @Auth(RoleEnum.ADMIN)
  deleteById(@Param('id') id: string) {
    return this.postsService.deletePostById(id);
  }
}
