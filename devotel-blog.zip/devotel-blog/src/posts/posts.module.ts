import { Module, OnApplicationBootstrap } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';

import { PostsController } from './controllers/posts.controller';

import { HttpModule } from '@nestjs/axios';
import { FirebaseService } from 'src/core/services/firebase.service';
import { PostEntity } from './models/post.entity';
import { PostRepository } from './repositories/post.repository';
import { PostsService } from './services/posts.service';

@Module({
  imports: [TypeOrmModule.forFeature([PostEntity]), HttpModule],
  providers: [PostsService, FirebaseService, PostRepository],
  exports: [PostsService],
  controllers: [PostsController],
})
export class PostsModule {}
