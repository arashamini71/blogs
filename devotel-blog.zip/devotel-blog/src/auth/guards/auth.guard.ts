import {
  Injectable,
  CanActivate,
  ExecutionContext,
  UnauthorizedException,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { FirebaseService } from 'src/core/services/firebase.service';

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(
    private reflector: Reflector,
    private firebaseService: FirebaseService,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const idToken = context.getArgs()[0]?.headers?.authorization.split(' ')[1];

    const roles = this.reflector.get<string[]>('roles', context.getHandler());
    try {
      const claims = await this.firebaseService.verifyIdToken(idToken);

      if (roles.includes(claims.role)) {
        return true;
      }

      throw new UnauthorizedException();
    } catch (error) {
      throw new UnauthorizedException();
    }
  }
}
